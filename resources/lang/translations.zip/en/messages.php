<?php

return [
    'people.reading' => '{0} Currently read by :count nobody|{1} Currently read by :count person|[2,*] Currently read by :count people',
    'comments' => '{0} No comments yet|{1} :count comment|[2,*] :count comments'
];
